<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="scss">
  html,body {
    width: 100%;
    height: 100%;
  }
  #app {
     width: 100%;
    height: 100%;
  }
</style>

